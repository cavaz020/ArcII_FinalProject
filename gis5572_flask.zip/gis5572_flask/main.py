import os
import string
import psycopg2
from flask import Flask, request
app = Flask(__name__)

# @app.route("/")
# def hello_world():
# 	name = os.environ.get("NAME", "World")
# 	return "Hello {}".format(name)

@app.route('/IDW')
def get_idw_map():
    # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch geojson
    query = """WITH ele_idw as (SELECT pointid, grid_code, st_transform((ST_SetSRID(Shape,32615)),4326) FROM elevation_idw) SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM ele_idw as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_string = response[0]
    return json_string

@app.route('/kriging')
def get_kriging_map():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """WITH ele_krig as (SELECT pointid, grid_code, st_transform((ST_SetSRID(Shape,32615)),4326) FROM elevation_krig) SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM ele_krig as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_krig = response[0]
    return json_krig

@app.route('/gpi')
def get_gpi_map():
        # create connection
    conn = psycopg2.connect("dbname='postgres' user='postgres' host='34.72.222.158' password='postgres'")
    cur = conn.cursor()
    # Fetch Polygon
    query = """WITH ele_gpi as (SELECT pointid, grid_code, st_transform((ST_SetSRID(Shape,32615)),4326) FROM elevation_gpi) SELECT json_build_object('type'::TEXT, 'FeatureCollection'::TEXT, 'features'::TEXT, json_agg(ST_AsGeoJSON(t.*)::json)) FROM ele_gpi as t;"""
    cur.execute(query)
    response = cur.fetchone()
    json_gpi = response[0]
    return json_gpi

# route only prints data to console
# @app.route('/print_data', methods=['POST'])
# def print_data():
#   print("*********************")
#   print("*********************")
#   print(request.method) # finds method -> here it should be "POST"
#   print(request.data) # generic - get all data; covers case where you don't know what's coming
#   print(request.json) # parses json data
#   print("*********************")
#   print("*********************")
#   return "Accepted 202 - post received; printed to console"


if __name__ == "__main__":
	app.run(debug = True, host = "0.0.0.0", port = int(os.environ.get("PORT", 8080)))

